package com.example.covid_19;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnl;
    Button btnl1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnl=findViewById(R.id.btnl);
        btnl1=findViewById(R.id.btnl1);
        btnl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, Curb.class);
                startActivity(intent);
            }

        });
        btnl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View w) {
                Intent intent1 = new Intent(MainActivity.this, LockedDown.class);
                startActivity(intent1);
            }
        });




    }
}
