package com.example.covid_19;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class Curb extends AppCompatActivity {

    Button backBtn;
    BarChart barChart;
    ArrayList<BarEntry> barEntryArrayList;
    ArrayList<String> labelsNames;
    ArrayList<Chart> ChartArrayList= new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_curb);
       backBtn = findViewById(R.id.backBtn);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Curb.this, MainActivity.class));
            }
        });

        barChart = findViewById(R.id.barChart);
        barEntryArrayList = new ArrayList<>();
        labelsNames = new ArrayList<>();
        fillMonthSales();


        for (int i = 0; i < ChartArrayList.size(); i++) {
            String date = ChartArrayList.get(i).getDate();
            int infections = ChartArrayList.get(i).getInfections();
            barEntryArrayList.add(new BarEntry(i, infections));
            labelsNames.add(date);
        }


        BarDataSet barDataSet = new BarDataSet(barEntryArrayList, "Daily tally of infections");
        barDataSet.setColors(ColorTemplate.COLORFUL_COLORS );
        Description description=new Description();
        description.setText("Day");
        barChart.setDescription(description);
        BarData barData=new BarData(barDataSet);
        barChart.setData(barData);
        XAxis xAxis=barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labelsNames));
        xAxis.setPosition(XAxis.XAxisPosition.TOP);
        xAxis.setDrawGridLines(false);
        xAxis.setDrawAxisLine(false);
        xAxis.setGranularity(1f);
        xAxis.setLabelCount(labelsNames.size());
        xAxis.setLabelRotationAngle(270);
        barChart.animateY(2000);
        barChart.invalidate();


    }
    private void fillMonthSales(){
        ChartArrayList.clear();
        ChartArrayList.add(new Chart("19th April", 2948));
        ChartArrayList.add(new Chart("20th April", 3382));
    }
}
