package com.example.covid_19;


public class Chart {
    String date;
    int infections;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getInfections() {
        return infections;
    }

    public void setInfections(int infections) {
        this.infections = infections;
    }

    public Chart(String date, int infections){
        this.date = date;
        this.infections = infections;

    }


}
